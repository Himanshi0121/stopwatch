package com.example.stopwatch_akanksha;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
